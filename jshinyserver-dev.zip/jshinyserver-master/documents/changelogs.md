## Change logs

### 0.94

1. Support shiny app with Unicode folder names
2. Support multiple shiny versions (CRAN 0.12.0 - 0.14.2)
3. Support new features in shiny versions 0.14 (sanitize errors, server-side bookmarking)  
4. Support to start new R instances for each user  
5. Support shiny version(>=0.14) from github or CRAN [Experimental](#note1) 
6. Support shiny app inside r markdown file (interactive document) [Experimental](#note1)  


### 0.91
   Initial release  



<a name="note1"></a>  
### Note 
   Experimental features may be removed in future versions 

